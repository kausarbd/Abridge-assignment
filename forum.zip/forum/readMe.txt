

IDE:Intelij Idea 15
Programming Lanaguage: Java

Java Technology :jsp and servlet.

Databas:Mysql
-----------------
Database config. class :src.db.Db.class

Initial Config. Information
_____________________________

Databas Name:forum_db
DbURL=jdbc:mysql://localhost:3306/forum_db
User:root
Password:"";   //( no password used)

------------------
All user password in database are:12345
only sunny is:123456