-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Feb 21, 2017 at 04:32 PM
-- Server version: 10.1.19-MariaDB
-- PHP Version: 7.0.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `forum_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `comment`
--

CREATE TABLE `comment` (
  `id` int(11) NOT NULL,
  `text` text NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `threadId` int(11) NOT NULL,
  `userId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `comment`
--

INSERT INTO `comment` (`id`, `text`, `createdAt`, `updatedAt`, `threadId`, `userId`) VALUES
(18, '<p>A JSP Lifecycle consists of following steps:</p>\r\n\r\n<ul>\r\n	<li>\r\n	<p><strong>Compilation</strong>: When a browser asks for a JSP, the JSP engine first checks to see whether it needs to compile the page. If the page has never been compiled, or if the JSP has been modified since it was last compiled, the JSP engine compiles the page.</p>\r\n\r\n	<p>The compilation process involves three steps:</p>\r\n\r\n	<ul>\r\n		<li>\r\n		<p>Parsing the JSP.</p>\r\n		</li>\r\n		<li>\r\n		<p>Turning the JSP into a servlet.</p>\r\n		</li>\r\n		<li>\r\n		<p>Compiling the servlet.</p>\r\n		</li>\r\n	</ul>\r\n	</li>\r\n	<li>\r\n	<p><strong>Initialization:</strong>&nbsp;When a container loads a JSP it invokes the jspInit() method before servicing any requests</p>\r\n	</li>\r\n	<li>\r\n	<p><strong>Execution:</strong>&nbsp;Whenever a browser requests a JSP and the page has been loaded and initialized, the JSP engine invokes the _jspService() method in the JSP.The _jspService() method of a JSP is invoked once per a request and is responsible for generating the response for that request and this method is also responsible for generating responses to all seven of the HTTP methods ie. GET, POST, DELETE etc.</p>\r\n	</li>\r\n	<li>\r\n	<p><strong>Cleanup:</strong>&nbsp;The destruction phase of the JSP life cycle represents when a JSP is being removed from use by a container.The jspDestroy() method is the JSP equivalent of the destroy method for servlets.</p>\r\n	</li>\r\n</ul>\r\n', '2017-02-21 20:53:13', '2017-02-21 20:53:13', 5, 3),
(23, '<p>JavaServer Pages (JSP) is a technology for developing web pages&nbsp;</p>\r\n', '2017-02-21 21:24:44', '2017-02-21 21:24:44', 4, 6);

-- --------------------------------------------------------

--
-- Table structure for table `thread`
--

CREATE TABLE `thread` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `body` text,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `userId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `thread`
--

INSERT INTO `thread` (`id`, `title`, `body`, `createdAt`, `updatedAt`, `userId`) VALUES
(4, 'What is JSP?', '<p>JavaServer Pages (JSP) is a technology for developing web pages that support dynamic content which helps developers insert java code in HTML pages by making use of special JSP tags, most of which start with &lt;% and end with %&gt;.</p>\r\n', '2017-02-21 20:49:08', '2017-02-21 20:49:08', 1),
(5, 'Explain lifecycle of a JSP?', '', '2017-02-21 20:50:15', '2017-02-21 21:00:41', 1),
(6, 'What do the id and scope attribute mean in the action elements in jsp?', '<p>asdas</p>\r\n', '2017-02-21 20:54:33', '2017-02-21 21:06:31', 3),
(7, ' JSP actions ', '<p>JSP actions use constructs in XML syntax to control the behavior of the servlet engine. You can dynamically insert a file, reuse JavaBeans components, forward the user to another page, or generate HTML for the Java plugin.</p>\r\n\r\n<p>Its syntax is as follows:</p>\r\n\r\n<pre>\r\n&lt;jsp:action_name attribute=&quot;value&quot; /&gt;</pre>\r\n', '2017-02-21 21:10:37', '2017-02-21 21:10:37', 3);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` bigint(20) NOT NULL,
  `fullName` varchar(255) NOT NULL,
  `userName` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `fullName`, `userName`, `password`, `createdAt`, `updatedAt`) VALUES
(1, 'kausar Ahosan', 'kausar', '8cb2237d0679ca88db6464eac60da96345513964', '2017-02-17 22:46:12', '2017-02-17 22:46:12'),
(3, 'Nasir Hosain', 'nasir', '8cb2237d0679ca88db6464eac60da96345513964', '2017-02-19 00:40:50', '2017-02-19 00:40:50'),
(4, 'Kausar Ahosan', 'kausar_nasir', '8cb2237d0679ca88db6464eac60da96345513964', '2017-02-19 13:58:49', '2017-02-19 13:58:49'),
(5, 'Sabina Sultana', 'sabina', '8cb2237d0679ca88db6464eac60da96345513964', '2017-02-21 12:22:31', '2017-02-21 12:22:31'),
(6, 'Sanny', 'sanny', '8cb2237d0679ca88db6464eac60da96345513964', '2017-02-21 21:24:19', '2017-02-21 21:24:19');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `comment`
--
ALTER TABLE `comment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `thread`
--
ALTER TABLE `thread`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `userName` (`userName`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `comment`
--
ALTER TABLE `comment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
--
-- AUTO_INCREMENT for table `thread`
--
ALTER TABLE `thread`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
