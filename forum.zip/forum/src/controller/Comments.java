package controller;

import common.Authentication;
import common.FormattedDate;
import common.HelperFunctions;
import dao.CommentDao;
import model.*;
import model.Thread;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@WebServlet(name = "Comments" ,urlPatterns = "/comment")
public class Comments extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {


        HelperFunctions helperFunction=new HelperFunctions();
        helperFunction.redirectDbErrorPage(request,response);
        Authentication authentication=new Authentication();
        HttpSession session=request.getSession();
        if(authentication.isUserLogin(request)){
            HelperFunctions helperFunctions=new HelperFunctions();
            String sessionAuthToken=(String) session.getAttribute("authToken");
            String authToken=request.getParameter("authToken");
            // Checking AuthToken
            if(authToken.equals(sessionAuthToken)){
                String text=request.getParameter("commentText");
                String cleanBody=helperFunctions.stripXSS(text);
                // form error message will go here
                Map<String,String> errorsMap=new HashMap<String, String>();
                // form posting data will go here
                Map<String,String> formData=new HashMap<String, String>();

                boolean isBodyEmpty=cleanBody.isEmpty();

                // get form action parameter value
                String action=request.getParameter("action");

                // getting login user Object

                String createdAt= FormattedDate.getFormattedDate(new Date(),"yyyy/MM/dd HH:mm:ss");
                String updatedAt=createdAt;

                User user=Authentication.getLoginUser(request);

                String threadId=request.getParameter("threadId");
                if(action.equals("AddComment")){

                    int threadIdInt=Integer.parseInt(threadId);
                    if((threadId!=null) &&(threadIdInt>0) &&(!isBodyEmpty)){
                        Comment comment=new Comment();
                        comment.setText(cleanBody);
                        model.Thread thread=new Thread();
                        thread.setId(threadIdInt);
                        comment.setThread(thread);
                        comment.setUser(user);
                        comment.setCreatedAt(createdAt);
                        comment.setUpdatedAt(updatedAt);
                       int insertedId= CommentDao.insert(comment);
                        if(insertedId>0){
                            response.sendRedirect("/thread?action=details&id="+threadId+"#comment-"+insertedId);
                        }else{
                            response.sendRedirect("/thread?action=details&id="+threadId);
                        }

                    }else{
                        response.sendRedirect("/thread");
                    }

                }else if(action.equals("EditComment")){
                    String id=request.getParameter("id");
                    if(!(id==null)||(id=="")){
                        int commentId=Integer.parseInt(id);
                        if(commentId>0 &&(!isBodyEmpty)){
                            Comment comment=new Comment();
                            comment.setId(commentId);
                            comment.setText(cleanBody);
                            comment.setUpdatedAt(updatedAt);
                            CommentDao.update(comment);
                        }
                        response.sendRedirect("/thread?action=details&id="+threadId+"#comment-"+id);
                    }else{
                        response.sendRedirect("/thread");
                    }



                }
                // set comment data

            }else{
                response.sendRedirect("/thread");
            }

        }else{
            response.sendRedirect("/login");
        }



    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HelperFunctions helperFunction=new HelperFunctions();
        helperFunction.redirectDbErrorPage(request,response);
        String pathInfo = request.getPathInfo();
        Authentication authentication=new Authentication();
        String action=request.getParameter("action");
        if (Authentication.isUserLogin(request)){


            if(action!=null) {
                if (action.equals("delete")) {
                    String id=request.getParameter("id");
                    if(!id.isEmpty()&& id!=null){
                        int commentId=Integer.parseInt(id);
                        doDelete(request, response,commentId);
                    }else{
                        response.sendRedirect("/thread");
                    }

                } else if(action.equals("edit")){
                    String id=request.getParameter("id");
                    if(!id.isEmpty()&& id!=null){
                        int commentId=Integer.parseInt(id);
                        Comment comment=CommentDao.getComment(commentId);
                    User user= Authentication.getLoginUser(request);
                       int userId= comment.getUser().getId();
                        if(user.getId()==userId){
                            request.setAttribute("comment",comment);
                            request.getRequestDispatcher("/WEB-INF/view/comment/edit.jsp").include(request,response);
                        }else{
                            request.setAttribute("illegalActionMessage","You Can not edit that because its is not your comment");
                            request.getRequestDispatcher("/WEB-INF/view/error/illegal_action.jsp").include(request,response);
                        }

                    }else{
                        response.sendRedirect("/thread");
                    }

                }else{
                    response.sendRedirect("/thread");
                }
            }

        }else{

      response.sendRedirect("/login");
        }





    }

    private void doDelete(HttpServletRequest request, HttpServletResponse response,int id) throws ServletException, IOException{

        if(Authentication.isUserLogin(request)){
            User user =Authentication.getLoginUser(request);
            HttpSession session=request.getSession();
            int commentId=id;
            Comment comment=null;
            if(commentId>0){
                comment= CommentDao.getComment(commentId);
                int commentUserId=comment.getUser().getId();
                if(commentUserId==user.getId()){
                    // delete thread
                   boolean isDeleted= CommentDao.delete(commentId);
                    if(isDeleted){
                        session.setAttribute("commentDeleteMessage","One Comment has been deleted");
                    }else {
                        session.setAttribute("commentDeleteMessage","Comment is not deleted.Try Again");
                    }
                    response.sendRedirect("/thread?action=details&id="+comment.getThread().getId());
                }else{
                    // show error for another thread
                    request.setAttribute("illegalActionMessage","You Can not delete that because its is not your comment");
                    request.getRequestDispatcher("/WEB-INF/view/error/illegal_action.jsp").include(request,response);
                }
            }else{
                response.sendRedirect("/thread");

            }
        }else{
            request.getSession().setAttribute("redirectUrl","/thread?action=delete&id="+id);
            response.sendRedirect("/login");
        }


    }
}
