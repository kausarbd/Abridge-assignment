package controller;

import common.Authentication;
import common.FormattedDate;
import common.HelperFunctions;
import dao.ThreadDao;
import model.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@WebServlet(name = "thread",urlPatterns = {"/thread"})

public class Thread extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        HelperFunctions helperFunction=new HelperFunctions();
        helperFunction.redirectDbErrorPage(request,response);
        Authentication authentication=new Authentication();
        HttpSession session=request.getSession();
        String action=request.getParameter("action");
        if(authentication.isUserLogin(request)){
            HelperFunctions helperFunctions=new HelperFunctions();
            String sessionAuthToken=(String) session.getAttribute("authToken");
            String authToken=request.getParameter("authToken");
            // Checking AuthToken
            if(authToken.equals(sessionAuthToken)){

                if(action.equals("AddThread")|| action.equals("EditThread")){
                    String title=request.getParameter("title");
                    String body=request.getParameter("body");
                    String cleanTitle=helperFunctions.stripXSS(title);
                    String cleanBody=helperFunctions.stripXSS(body);
                    // form error message will go here
                    Map<String,String> errorsMap=new HashMap<String, String>();
                    // form posting data will go here
                    Map<String,String> formData=new HashMap<String, String>();
                    boolean isTitleEmpty=cleanTitle.isEmpty();
                    boolean isBodyEmpty=cleanBody.isEmpty();
                    String ss;
                    ss=(isTitleEmpty)?errorsMap.put("title","Title field is required"):formData.put("title",cleanTitle);
                    ss=(isBodyEmpty)?"":formData.put("body",cleanBody);
                    // get form action parameter value

                    request.setAttribute("formErrors",errorsMap);
                    request.setAttribute("formData",formData);
                    // getting login user Object
                    User user=authentication.getLoginUser(request);
                    String createdAt= FormattedDate.getFormattedDate(new Date(),"yyyy/MM/dd HH:mm:ss");
                    String updatedAt=createdAt;
                    // set data to Thread Model
                    model.Thread thread=new model.Thread();

                    if(action.equals("AddThread")){
                        thread.setTitle(cleanTitle);
                        thread.setBody(cleanBody);
                        thread.setCreatedAt(createdAt);
                        thread.setUpdatedAt(updatedAt);
                        thread.setUser(user);
                        int insertedId=0;
                        if(!isTitleEmpty){
                            // insert action
                            insertedId= ThreadDao.insert(thread);
                            if(insertedId>0){
                                response.sendRedirect("/thread?action=details&id="+insertedId);
                            }else {
                                response.sendRedirect("/thread?action=add");
                            }
                        }else{
                            response.sendRedirect("/thread?action=add");
                        }
                    }else if(action.equals("EditThread")){
                        String id=request.getParameter("id");
                        thread.setId(Integer.parseInt(id));
                        thread.setTitle(cleanTitle);
                        thread.setBody(cleanBody);
                        thread.setCreatedAt(createdAt);
                        thread.setUpdatedAt(updatedAt);
                        thread.setUser(user);
                        boolean isUpdate=false;
                        if(!isTitleEmpty){
                            // insert action
                            isUpdate= ThreadDao.update(thread);
                            if(isUpdate){
                                session.setAttribute("threadUpdateMessage","Thread has been Updated");

                            }else {
                                session.setAttribute("threadUpdateMessage","Thread is not Updated");
                            }

                            response.sendRedirect("/thread?action=details&id="+id);
                        }else{
                            response.sendRedirect("/thread?action=edit&id="+id);
                        }
                    }else{
                        response.sendRedirect("/thread");
                    }

                }else if(action.equals("search")){
                    String searchText=request.getParameter("search");
                    request.setAttribute("searchText",searchText);
                    if(!searchText.isEmpty()){
                        searchText=helperFunction.stripXSS(searchText);
                        doSearch(request,response,searchText);
                    }else{
                        response.sendRedirect("/thread");
                    }

                }else{
                    response.sendRedirect("/thread");
                }

            }else{
                response.sendRedirect("/thread");
            }

        }else {
            if(action.equals("search")){
                String searchText=request.getParameter("search");
                request.setAttribute("searchText",searchText);
                if(!searchText.isEmpty()){
                    searchText=helperFunction.stripXSS(searchText);
                    List<model.Thread> threadList=ThreadDao.getSearchResult(searchText);
                    request.setAttribute("threadList",threadList);

                    request.getRequestDispatcher("/WEB-INF/view/thread/list.jsp").include(request,response);
                }else{
                    response.sendRedirect("/thread");
                }

            }else {
                response.sendRedirect("/login");
            }
        }



    }



    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HelperFunctions helperFunction=new HelperFunctions();
        helperFunction.redirectDbErrorPage(request,response);
        HttpSession session=request.getSession();
        String pathInfo = request.getPathInfo();
        Authentication authentication=new Authentication();
        String action=request.getParameter("action");
        request.setAttribute("currentAction",action);

            if(action!=null){
                if(action.equals("add")){
                    addForm(request,response);
                }else if(action.equals("edit")){
                    String id=request.getParameter("id");
                    if(id!=null ||id!=""){
                        try {
                            int threadId=Integer.parseInt(id);
                            editForm(request,response,threadId);
                        }catch (NumberFormatException ne){
                            response.sendRedirect("/threads");
                        }

                    }else{
                        response.sendRedirect("/threads");
                    }
                }else if(action.equals("delete")){
                    String id=request.getParameter("id");
                    if(id!=null ||id!=""){
                        try {
                            int threadId=Integer.parseInt(id);
                            doDelete(request,response,threadId);
                        }catch (NumberFormatException ne){

                        }


                    }else{
                        response.sendRedirect("/thread");
                    }


                }else if(action.equals("details")){
                    String id=request.getParameter("id");
                    if(id!=null ||id!=""){
                        try {
                            int threadId=Integer.parseInt(id);
                            view(request,response,threadId);
                        }catch (NumberFormatException ne){
                            response.sendRedirect("/thread");
                        }

                    }else{
                        response.sendRedirect("/thread");
                    }

                }else{
                    showList(request,response);
                }
            }else{
                showList(request,response);
            }








    }



    private void showList(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{

        HttpSession session=request.getSession();
        List<model.Thread> threadList= ThreadDao.getThreadList();
        request.setAttribute("threadList",threadList);
        request.getRequestDispatcher("/WEB-INF/view/thread/list.jsp").include(request,response);

    }
    private void addForm(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
        if(Authentication.isUserLogin(request)){
            request.getRequestDispatcher("/WEB-INF/view/thread/add.jsp").include(request,response);
        }else {
            request.getSession().setAttribute("redirectUrl","/thread?action=add");
           response.sendRedirect("/login");
        }


    }

    private void view(HttpServletRequest request, HttpServletResponse response,int id) throws ServletException, IOException{
        if(Authentication.isUserLogin(request)){

            model.Thread thread= ThreadDao.getThread(id);
            request.setAttribute("thread",thread);
                request.getRequestDispatcher("/WEB-INF/view/thread/view.jsp").include(request,response);


        }else {
            request.getSession().setAttribute("redirectUrl","/thread?action=details&id="+id);
            response.sendRedirect("/login");
        }


    }

    private void doSearch(HttpServletRequest request, HttpServletResponse response,String searchText) throws ServletException, IOException{
        if(Authentication.isUserLogin(request)){

          List<model.Thread> threadList=ThreadDao.getSearchResult(searchText);

            request.setAttribute("threadList",threadList);
            request.getRequestDispatcher("/WEB-INF/view/thread/list.jsp").include(request,response);
        }else {
            response.sendRedirect("/login");
        }


    }

    private void editForm(HttpServletRequest request, HttpServletResponse response,int id) throws ServletException, IOException{

        if(Authentication.isUserLogin(request)){
            HttpSession session=request.getSession();
            User user =Authentication.getLoginUser(request);
            int threadId=id;

            model.Thread thread=null;
            if(threadId>0){
                thread= ThreadDao.getThread(threadId);
                int threadUserId=thread.getUser().getId();

                if(threadUserId==user.getId()){

                    session.setAttribute("editThread",thread);
                    request.getRequestDispatcher("/WEB-INF/view/thread/edit.jsp").include(request,response);

                }else{
                    request.setAttribute("illegalActionMessage","You Can not edit that because its is not your thread");
                    request.getRequestDispatcher("/WEB-INF/view/error/illegal_action.jsp").include(request,response);

                }
            }else{
                response.sendRedirect("/thread");

            }
        }else{
            request.getSession().setAttribute("redirectUrl","/thread?action=edit&id="+id);
            response.sendRedirect("/login");
        }

    }

    private void doDelete(HttpServletRequest request, HttpServletResponse response,int id) throws ServletException, IOException{

        if(Authentication.isUserLogin(request)){
            User user =Authentication.getLoginUser(request);
            int threadId=id;

            model.Thread thread=null;
            if(threadId>0){
                thread= ThreadDao.getThread(threadId);
                int threadUserId=thread.getUser().getId();


                if(threadUserId==user.getId()){
                    // delete thread

                    boolean isDeleted=ThreadDao.delete(threadId);

                    if(isDeleted){
                        request.setAttribute("threadDeleteMessage","You Thread has been deleted");
                    }else{
                        request.setAttribute("threadDeleteMessage","You Thread is not delete,Try Again");
                    }
                    request.getRequestDispatcher("/WEB-INF/view/thread/deleted_message.jsp").include(request,response);
                }else{
                    // show error for another thread
                    request.setAttribute("illegalActionMessage","You Can not delete that because it is not your thread");
                    request.getRequestDispatcher("/WEB-INF/view/error/illegal_action.jsp").include(request,response);
                }
            }else{
                response.sendRedirect("/thread");

            }
        }else{
            request.getSession().setAttribute("redirectUrl","/thread?action=delete&id="+id);
            response.sendRedirect("/login");
        }


    }
}
