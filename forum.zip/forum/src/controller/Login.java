package controller;

import common.Authentication;

import common.HelperFunctions;
import common.PasswordHash;
import dao.UserDao;

import model.User;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.Map;



@WebServlet(name = "Login", urlPatterns = {"/login"})
public class Login extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HelperFunctions helperFunction=new HelperFunctions();
            helperFunction.redirectDbErrorPage(request,response);

        HttpSession session=request.getSession();
        String sessionToken = (String) session.getAttribute("authToken");
        String authToken = request.getParameter("authToken");

        String userName = request.getParameter("userName");
        String password = request.getParameter("password");
        Map<String,String> errorsMap=new HashMap<String, String>();
        Map<String,String> formData=new HashMap<String, String>();
     if ((!sessionToken.isEmpty()) && (authToken.equals(sessionToken)) &&(!userName.isEmpty()) &&(!password.isEmpty())) {
         PasswordHash hp=new PasswordHash();
         String hashedPassword=null;
         try {
              hashedPassword=hp.getHashedPassword(password);
         } catch (NoSuchAlgorithmException e) {
             response.sendRedirect("/");
         }

         UserDao useDao=new UserDao();
       User user= useDao.getUser(userName,hashedPassword);
         if(user!=null){
             session.setAttribute("loginUser",user);
             User userSes=(User) session.getAttribute("loginUser");

            String url= (String) session.getAttribute("redirectUrl");
             if(!(url == null)){
                 session.removeAttribute("redirectUrl");
                 response.sendRedirect(url);

             }else{
                 response.sendRedirect("/");
             }

         }else {
             formData.put("userName",userName);
             formData.put("password",password);
             session.setAttribute("formData",formData);
             session.setAttribute("loginErrorMessage","User name and password not matching");
             response.sendRedirect("/login");
         }

     } else {

         String ss=null;
         ss= (userName.isEmpty())?errorsMap.put("userName","User name field is required"):formData.put("userName",userName);
         ss=(password.isEmpty())?errorsMap.put("password","Password field is required"):formData.put("password",password);
         session.setAttribute("formData",formData);
         session.setAttribute("formErrors",errorsMap);
            response.sendRedirect("/login");
        }



    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HelperFunctions helperFunction=new HelperFunctions();
        helperFunction.redirectDbErrorPage(request,response);
        HttpSession session=request.getSession();
        if(!Authentication.isUserLogin(request)){
            request.getRequestDispatcher("/WEB-INF/view/login/index.jsp").include(request,response);
        }else{
            response.sendRedirect("/");
        }

    }
}
