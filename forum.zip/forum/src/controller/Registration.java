package controller;

import common.Authentication;
import common.FormattedDate;
import common.HelperFunctions;
import common.PasswordHash;
import dao.UserDao;
import model.User;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;


@WebServlet(name = "Registration",urlPatterns = {"/registration","/registration_action"})

public class Registration extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HelperFunctions helperFunction=new HelperFunctions();
        helperFunction.redirectDbErrorPage(request,response);
        Authentication authentication=new Authentication();
        HttpSession session=request.getSession();
        if(authentication.isUserLogin(request)){
            response.sendRedirect("/");
        }else{
            String action=request.getServletPath();
            if(action.equals("/registration_action")){
                response.sendRedirect("/registration");
            }else {
                RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/view/user/registration.jsp");
                dispatcher.forward(request, response);
            }

        }


    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HelperFunctions helperFunction=new HelperFunctions();
          helperFunction.redirectDbErrorPage(request,response);
        Authentication authentication=new Authentication();
        HttpSession session=request.getSession();

        // Checking is user is logged in
        if(authentication.isUserLogin(request)){
            response.sendRedirect("/");
        }else{
            String sessionAuthToken = (String) session.getAttribute("authToken");
            String authToken = request.getParameter("authToken");
            String fullName = request.getParameter("fullName");
            String userName = request.getParameter("userName");
            String password = request.getParameter("password");
            String confirmPassword = request.getParameter("confirmPassword");


            boolean isAuthTokenEmpty=authToken.isEmpty();
            boolean isAuthTokenAndSessionAuthTokenEquals=authToken.equals(sessionAuthToken);
            boolean isUserNameEmpty=userName.isEmpty();
            boolean isFullNameEmpty=fullName.isEmpty();
            boolean isPasswordEmpty=password.isEmpty();
            boolean isConfirmPasswordEmpty=confirmPassword.isEmpty();
            boolean isPasswordAndConfirmPasswordEqual=password.equals(confirmPassword);
            // form validation logic
            boolean isRegistrationFormValid=((!isAuthTokenEmpty)&& (isAuthTokenAndSessionAuthTokenEquals) &&(!isUserNameEmpty) &&(!isFullNameEmpty) &&(!isPasswordEmpty)&&(isPasswordAndConfirmPasswordEqual)&&(!isConfirmPasswordEmpty));

            // form error message will go here
            Map<String,String> errorsMap=new HashMap<String, String>();
            // form posting data will go here
            Map<String,String> formData=new HashMap<String, String>();
            String ss=null;// handling for not a statement error in ternary operator
            // putting form validation error message or form posting data
            ss= (isFullNameEmpty)?errorsMap.put("fullName"," Name field is required"):formData.put("fullName",fullName);
            ss= (isUserNameEmpty)?errorsMap.put("userName","User name field is required"):formData.put("userName",userName);
            ss=(isPasswordEmpty)?errorsMap.put("password","Password field is required"):formData.put("password",password);
            ss=(isConfirmPasswordEmpty)?errorsMap.put("confirmPassword","Confirm password field is required"):formData.put("confirmPassword",confirmPassword);
            if(!isPasswordEmpty &&!isConfirmPasswordEmpty){
                ss=(isPasswordAndConfirmPasswordEqual)?errorsMap.put("confirmPassword","Password is matched"):errorsMap.put("confirmPassword","Password is not matched");
            }

            boolean isUserNameExist=false;
            UserDao userDao=new UserDao();
            // Checking is username exist in user
            if(!isUserNameEmpty){

                isUserNameExist= userDao.isUSerNameExist(userName);

                if(isUserNameExist){
                    errorsMap.put("userName","User name is already exist,Try another");
                }
            }
            // putting form posting data to session to set in registration form
            session.setAttribute("formData",formData);
            // putting form errors messages to session to show user
            session.setAttribute("formErrors",errorsMap);
            // Check form validation
            if (isRegistrationFormValid && !isUserNameExist) {

                    // Hashing plain text password
                    PasswordHash hp=new PasswordHash();
                    String hashedPassword=null;
                    try {
                        hashedPassword=hp.getHashedPassword(password);
                    } catch (NoSuchAlgorithmException e) {
                        response.sendRedirect("/registration");
                    }
                    // setting data to User model class
                    User user=new User();
                    user.setFullName(fullName.trim());
                    user.setUserName(userName.trim());
                    user.setPassword(hashedPassword);
                    Date date = new Date();
                    FormattedDate fd=new FormattedDate();
                    String formattedDate=fd.getFormattedDate(date,"yyyy/MM/dd HH:mm:ss");
                    user.setCreatedAt(formattedDate);
                    user.setUpdatedAt(formattedDate);

                    // inserting user registration data into database
                  boolean is_save=  userDao.insert(user);
                    if(is_save){
                        // Allowing new registration user as logged in user
                         user= userDao.getUser(userName,hashedPassword);
                        session.setAttribute("loginUser",user);
                        User userSes=(User) session.getAttribute("loginUser");
                        response.sendRedirect("/");
                    }else{
                        response.sendRedirect("/registration");
                    }





            }else{


                response.sendRedirect("/registration");

            }

        }




    }


}
