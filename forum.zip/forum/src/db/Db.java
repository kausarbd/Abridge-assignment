package db;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class Db {

    //Database Driver Name
    static final String  JDBC_DRIVER= "com.mysql.jdbc.Driver";
    //DB Url where forum_db is database name
    static final String DB_URL ="jdbc:mysql://localhost:3306/forum_db";
    // Database User Name
    static final String USER ="root";
    // Database Password
    static final String PASSWORD ="";

    static Connection connection = null;

    public static Connection getConnection(){
        try {
            Class.forName(JDBC_DRIVER);
            connection = DriverManager.getConnection(DB_URL,USER,PASSWORD);
        }catch (ClassNotFoundException e) {
            e.printStackTrace();
        }catch (SQLException e) {
            e.printStackTrace();
        }
        return connection;

    }

}
