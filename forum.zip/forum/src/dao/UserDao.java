package dao;

import db.Db;
import model.User;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
public class UserDao {

    static  final String tableName="user";
    Connection con=null;

   public boolean insert(User user){
        String sql="insert into "+UserDao.tableName+" (fullName,userName,password,createdAt,updatedAt) values(?,?,?,?,?)";
        try{
            con= Db.getConnection();
            PreparedStatement ps =  con.prepareStatement(sql);
            ps.setString(1,user.getFullName());
            ps.setString(2, user.getUserName());
            ps.setString(3, user.getPassword());
            ps.setString(4, user.getCreatedAt());
            ps.setString(5, user.getUpdatedAt());
            ps.executeUpdate();
            con.close();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (Exception e) {

        }
        return false;

    }

    public User getUserById(String id){

        User user=null;
        String sql="select * from "+UserDao.tableName+" where id=?";
        try {
            con= Db.getConnection();
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setMaxRows(1);
            ps.setString(1, id);
            ResultSet rs=ps.executeQuery();
            while(rs.next()){
                user=this.setUserdata(rs);
            }
            con.close();

        } catch (SQLException e) {

        }catch (Exception e) {

        }

        return user;
    }

    public User getUser(String userName,String password ){

        User user=null;
        String sql="select * from "+UserDao.tableName+" where userName=? and password=?";
        try {
            con= Db.getConnection();
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setMaxRows(1);
            ps.setString(1,userName);
            ps.setString(2,password);
            ResultSet rs=ps.executeQuery();
            while(rs.next()){
                user=this.setUserdata(rs);
            }


            con.close();

        } catch (SQLException e) {

        }catch (Exception e) {

        }

        return user;
    }



    public static User setUserdata(ResultSet rs) throws SQLException {
        User user=new User();;
            user.setId(rs.getInt(1));
            user.setFullName(rs.getString(2));
            user.setUserName(rs.getString(3));
            user.setCreatedAt(rs.getString(4));
            user.setUpdatedAt(rs.getString(5));
        return user;
    }

    public boolean isUSerNameExist(String userName){

        String sql="select * from "+UserDao.tableName+" where userName=?";
        try {
            con= Db.getConnection();
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setMaxRows(1);
            ps.setString(1,userName);
            ResultSet rs=ps.executeQuery();
            while(rs.next()){
                return true;
            }
            con.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }catch (Exception e) {
            e.printStackTrace();
        }
        return  false;
    }

}
