package dao;
import db.Db;
import model.Thread;
import model.User;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ThreadDao {

    static  final String tableName="thread";
   static Connection con=null;

    public static int insert(Thread thread){
        String sql="insert into "+ThreadDao.tableName+" (title,body,createdAt,updatedAt,userId) values(?,?,?,?,?)";
        int insertedId=0;
        try{
            con= Db.getConnection();
            PreparedStatement ps =  con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            ps.setString(1,thread.getTitle());
            ps.setString(2,thread.getBody());
            ps.setString(3,thread.getCreatedAt());
            ps.setString(4,thread.getUpdatedAt());
            ps.setInt(5,thread.getUser().getId());
            ps.executeUpdate();
            ResultSet rs = ps.getGeneratedKeys();
            if(rs.next()){
               return rs.getInt(1);
            }
            con.close();

        } catch (SQLException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return insertedId;

    }

    public static boolean update(Thread thread){
        String sql="update  "+ThreadDao.tableName+" set title=?,body=?,updatedAt=? where id=?";
        try{
            con= Db.getConnection();
            PreparedStatement ps =  con.prepareStatement(sql);
            ps.setString(1,thread.getTitle());
            ps.setString(2,thread.getBody());
            ps.setString(3,thread.getUpdatedAt());
            ps.setInt(4,thread.getId());
            ps.executeUpdate();
            con.close();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;

    }


    public static List<Thread> getThreadList(){
        List<Thread> threadList=new ArrayList<Thread>();
        Thread thread=null;
        User user=null;

        String sql="select * from "+ThreadDao.tableName+" order by id DESC";

        String sqlUser="select * from "+UserDao.tableName+" where id=?";

        try{
            con= Db.getConnection();
            PreparedStatement ps =  con.prepareStatement(sql);

            ResultSet rs= ps.executeQuery();
            ResultSet rsUser=null;
            PreparedStatement psUser =  con.prepareStatement(sqlUser);

            while (rs.next()) {
                thread=ThreadDao.setThreadData(rs);
                //set current thread user
                psUser.setInt(1,rs.getInt(6));
                psUser.setMaxRows(1);
                rsUser= psUser.executeQuery();
                while (rsUser.next()) {
                    user=new User();
                    user.setId(rsUser.getInt(1));
                    user.setFullName(rsUser.getString(2));
                    user.setUserName(rsUser.getString(3));
                    user.setPassword(rsUser.getString(4));
                    user.setCreatedAt(rsUser.getString(5));
                    user.setUpdatedAt(rsUser.getString(6));

                }
                thread.setUser(user);
                threadList.add(thread);
            }

            con.close();
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return threadList;
    }

    public static Thread getThread(int id){
        Thread thread=null;
        String sql="select * from "+ThreadDao.tableName+" where id=?";
        String sqlUser="select * from "+UserDao.tableName+" where id=?";
        try{
            con= Db.getConnection();
            PreparedStatement ps =  con.prepareStatement(sql);
            ps.setMaxRows(1);
            ps.setInt(1,id);
            ResultSet rs= ps.executeQuery();
            while (rs.next()) {
                thread = ThreadDao.setThreadData(rs);
                PreparedStatement psUser =  con.prepareStatement(sqlUser);
                int userId=rs.getInt(6);
                psUser.setInt(1,rs.getInt(6));
                psUser.setMaxRows(1);
              ResultSet  rsUser= psUser.executeQuery();
                User user =null;
                while (rsUser.next()){
                    user=ThreadDao.setUserdata(rsUser);
                    thread.setUser(user);
                }

            }
            con.close();
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return thread;
    }

    public static List<Thread> getThreadListByUserId(int userId){
        List<Thread> threadListByUser =new ArrayList<Thread>();
        Thread threadByUser=null;
        User user=null;

        String sql="select * from "+ThreadDao.tableName+" where userId=?  order by id DESC";
        String sqlUser="select * from "+UserDao.tableName+" where id=?";

        try{
            con= Db.getConnection();
            PreparedStatement ps =  con.prepareStatement(sql);
            ps.setInt(1,userId);
            ResultSet rs= ps.executeQuery();
            ResultSet rsUser=null;
            PreparedStatement psUser =  con.prepareStatement(sqlUser);
            while (rs.next()) {
                threadByUser=ThreadDao.setThreadData(rs);
                //set current thread user
                psUser.setInt(1,rs.getInt(6));
                psUser.setMaxRows(1);
                rsUser= psUser.executeQuery();
                while (rsUser.next()) {
               user=UserDao.setUserdata(rsUser);
                }
                threadByUser.setUser(user);
                threadListByUser.add(threadByUser);
            }

            con.close();
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return threadListByUser;
    }

    public static Thread setThreadData(ResultSet rs){
        Thread thread=null;
        try {
                thread=new Thread();
                thread.setId(rs.getInt(1));
                thread.setTitle(rs.getString(2));
                thread.setBody(rs.getString(3));
                thread.setCreatedAt(rs.getString(4));
                thread.setUpdatedAt(rs.getString(5));
            return thread;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return thread;
    }

    private  static User setUserdata(ResultSet rs) throws SQLException {
            User user=null;
                user=new User();
                user.setId(rs.getInt(1));
                user.setFullName(rs.getString(2));
                user.setUserName(rs.getString(3));
                user.setCreatedAt(rs.getString(4));
                user.setUpdatedAt(rs.getString(5));
            return user;
        }

    public  static boolean delete(int id) {
        String sql="delete from "+ThreadDao.tableName+" where id=?";
        String sqlComment="delete from "+CommentDao.tableName+" where threadId=?";
        try{
            con= Db.getConnection();
            // first delete all comments fo that thread
            PreparedStatement psComment =  con.prepareStatement(sqlComment);
            psComment.setInt(1,id);
            psComment.executeUpdate();
            //Now thread thread
            PreparedStatement ps =  con.prepareStatement(sql);
            ps.setInt(1,id);
            ps.executeUpdate();
            con.close();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }




    public static List<Thread> getSearchResult(String searchText){
        List<Thread> threadListByUser =new ArrayList<Thread>();
        Thread threadByUser=null;
        User user=null;

        String sql="select * from "+ThreadDao.tableName+" where title like ? OR body like ?";

        String sqlUser="select * from "+UserDao.tableName+" where id=?";

        try{
            con= Db.getConnection();
            PreparedStatement ps =  con.prepareStatement(sql);
            ps.setString(1,"%"+searchText+"%");
            ps.setString(2,"%"+searchText+"%");
            ResultSet rs= ps.executeQuery();
            ResultSet rsUser=null;
            PreparedStatement psUser =  con.prepareStatement(sqlUser);
            while (rs.next()) {
                threadByUser=ThreadDao.setThreadData(rs);
                //set current thread user
                psUser.setInt(1,rs.getInt(6));
                psUser.setMaxRows(15);
                rsUser= psUser.executeQuery();
                while (rsUser.next()) {
                    user=UserDao.setUserdata(rsUser);
                }
                threadByUser.setUser(user);
                threadListByUser.add(threadByUser);
            }

            con.close();
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return threadListByUser;
    }




}
