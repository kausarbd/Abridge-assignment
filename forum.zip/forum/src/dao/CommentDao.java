package dao;

import db.Db;
import model.Comment;
import model.Thread;
import model.User;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CommentDao {
    static  final String tableName="comment";
    static Connection con=null;
    public static int insert(Comment comment){
        int insertedId=0;
        String sql="insert into "+CommentDao.tableName+" (text,createdAt,updatedAt,threadId,userId) values(?,?,?,?,?)";
        try{
            con= Db.getConnection();
            PreparedStatement ps =  con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            ps.setString(1,comment.getText());
            ps.setString(2,comment.getCreatedAt());
            ps.setString(3,comment.getUpdatedAt());
            ps.setInt(4,comment.getThread().getId());
            ps.setInt(5,comment.getUser().getId());
            ps.executeUpdate();
            ResultSet rs=ps.getGeneratedKeys();
            if(rs.next()){
               insertedId= rs.getInt(1);
            }
            con.close();
            return insertedId;
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return insertedId;

    }

    public static boolean update(Comment comment){

        String sql="update "+CommentDao.tableName+"  set text=?,updatedAt=? WHERE id=?";
        try{
            con= Db.getConnection();
            PreparedStatement ps =  con.prepareStatement(sql);
            ps.setString(1,comment.getText());
            ps.setString(2,comment.getUpdatedAt());
            ps.setInt(3,comment.getId());
            ps.executeUpdate();
            con.close();
            return  true;
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false ;

    }



    public static List<Comment> getCommentsByThreadId(int id){
        List<Comment> commentList=new ArrayList<Comment>();
        String sql="select * from "+CommentDao.tableName+" where threadId=?";
        String threadSql="select * from "+ThreadDao.tableName+" where id=?";
        String userSql="select * from "+UserDao.tableName+" where id=?";
        con= Db.getConnection();
        try {
            PreparedStatement ps =  con.prepareStatement(sql);
            ps.setInt(1,id);
            ResultSet rs=ps.executeQuery();
            while (rs.next()) {
                Comment comment=null;
                User user=null;
                Thread thread=null;
                comment=CommentDao.setCommentData(rs);
                PreparedStatement psUser =  con.prepareStatement(userSql);
                //set current thread user
                int userId =rs.getInt(6);
                psUser.setInt(1,userId);
                psUser.setMaxRows(1);
                ResultSet rsUser= psUser.executeQuery();
                while (rsUser.next()) {
                    // setting user details of comments
                    user=UserDao.setUserdata(rsUser);
                    comment.setUser(user);
                }

                PreparedStatement psThread=  con.prepareStatement(threadSql);
                int threadId =rs.getInt(5);
                psThread.setInt(1,threadId);
                psThread.setMaxRows(1);
                ResultSet rsThread= psUser.executeQuery();
                while (rsThread.next()) {
                    //set thread data
                   thread=  ThreadDao.setThreadData(rsThread);

                    comment.setThread(thread);
                }
                commentList.add(comment);
            }
            con.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }




        return commentList;
    }



    public static Comment setCommentData(ResultSet rs)  {
        Comment comment=null;
        try {
            comment=new Comment();
            comment.setId(rs.getInt(1));
            comment.setText(rs.getString(2));
            comment.setCreatedAt(rs.getString(3));
            comment.setUpdatedAt(rs.getString(4));

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return comment;
    }

    public  static boolean delete(int id) {
        String sql="delete from "+CommentDao.tableName+" where id=?";
        boolean isDeleted=false;
        try{
            con= Db.getConnection();
            PreparedStatement psc =  con.prepareStatement(sql);
            psc.setInt(1,id);
            psc.executeUpdate();
            con.close();
            isDeleted=true;
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return isDeleted;
    }


    public static Comment getComment(int id){
        Comment comment=null;
        String sql="select * from "+CommentDao.tableName+" where id=?";
        String sqlUser="select * from "+UserDao.tableName+" where id=?";
        String sqlThread="select * from "+ThreadDao.tableName+" where id=?";
        try{
            con= Db.getConnection();
            PreparedStatement ps =  con.prepareStatement(sql);
            ps.setMaxRows(1);
            ps.setInt(1,id);
            ResultSet rs= ps.executeQuery();
            while (rs.next()) {
                comment= CommentDao.setCommentData(rs);
                PreparedStatement psUser =  con.prepareStatement(sqlUser);
                psUser.setInt(1,rs.getInt(6));
                psUser.setMaxRows(1);
                ResultSet  rsUser= psUser.executeQuery();
                User user =null;
                while (rsUser.next()){
                    user=UserDao.setUserdata(rsUser);
                    comment.setUser(user);
                }

                PreparedStatement psThread =  con.prepareStatement(sqlThread);
                psThread.setInt(1,rs.getInt(5));
                psThread.setMaxRows(1);
                ResultSet  rsThread= psThread.executeQuery();
                Thread thread=null;
                while (rsThread.next()){
                    thread=ThreadDao.setThreadData(rsThread);
                    comment.setThread(thread);
                }

            }
            con.close();
            return  comment;
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return comment;
    }
}
