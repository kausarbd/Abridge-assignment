package common;


import dao.UserDao;
import model.User;
import javax.servlet.http.HttpServletRequest;
import java.util.Date;
import java.util.Random;


public class Authentication {

    public static String getRandomToken(){
        Date date=new Date();
        String SALTCHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890abcdefghijklmnopqrstuvwxyz"+date.getTime();
        StringBuilder salt = new StringBuilder();
        Random rnd = new Random();
        while (salt.length() < 40) {
            int index = (int) (rnd.nextFloat() * SALTCHARS.length());
            salt.append(SALTCHARS.charAt(index));
        }
        return  salt.toString();
    }

    public static boolean isUserLogin(HttpServletRequest request){
        User user=(User)request.getSession().getAttribute("loginUser");
       return (user!=null)?true:false;
    }

    public static User getLoginUser(HttpServletRequest request){
        return (User) request.getSession().getAttribute("loginUser");
    }

    //Check user exist in database
    public static boolean isUserExist(String userName, String password){
        UserDao useDao=new UserDao();
        User user= useDao.getUser(userName,password);
        return (user!=null)?true:false;
    }

}
