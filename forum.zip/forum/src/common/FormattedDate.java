package common;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.Instant;
import java.util.Date;


public class FormattedDate {


// Return formatted Date as String
    public static String getFormattedDate(Date date,String format){
        if((date!=null )&& (format!=null )&& (!format.isEmpty())){
            DateFormat dateFormat = new SimpleDateFormat(format);
            return  dateFormat.format(date);
        }else {
            return  null;
        }

    }


    public static String getPostPeriod(String dateTime) throws ParseException {
        SimpleDateFormat inFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date dtIn;
        dtIn = (Date) inFormat.parse(dateTime);
        Timestamp time=new Timestamp(dtIn.getTime());
        Instant instant = Instant.now();

        long days = Duration.between(instant, time.toInstant()).toDays();



        String text;
        if(days==0){
            // show hours
            long hours = Duration.between(instant, time.toInstant()).toHours();

            if(hours==0){
                // show minute
                long min = Duration.between(instant, time.toInstant()).toMinutes();
                if(min==0){
                    long millis = Duration.between(instant, time.toInstant()).toMillis();
                   long se= (millis /1000)%60;
                    text=String.valueOf(Math.abs(se));
                    return   text+" sec";
                }else{
                    text=String.valueOf(Math.abs(min));
                    return   text+" min";
                }

            }else {
                text=String.valueOf(Math.abs(hours));
                return text+" hrs";
                // hours
            }
        }else if(days<-7){
            // show date
            text=String.valueOf(Math.abs(days));
            return   text+" days";
            // hours
        }else if(days==-1){
            // show yesterday
            text=String.valueOf(Math.abs(days));
            return  "Yesterday";
        }else{
            return FormattedDate.getFormattedDate(dtIn,"MMMM d, ''yyyy");
        }


    }
}
